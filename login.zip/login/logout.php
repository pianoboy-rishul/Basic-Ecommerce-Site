<?php
session_start();
unset($POST["user"]);
unset($_POST["pass"]);
header ("Location: http://localhost/Ecommerce/index.php?status=success");
?>