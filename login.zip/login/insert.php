<?php
    include('connection.php');
    if(isset($_POST['submit']))
    {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        if($firstname !=''||$lastname !=''||$email !=''){
        $query = "INSERT INTO login(firstname, lastname, username, password) VALUES ('$firstname', '$lastname', '$email', '$password')";
        $sql=mysqli_query($con,$query)or die("Could Not Perform the Query");
        header ("Location: login.php?status=success");
        }
        else 
        {
		    echo "Error.Please try again";
	    }
    }
?>